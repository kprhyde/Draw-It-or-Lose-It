package com.gamingroom;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity {

	private static List<Team> teams = new ArrayList<Team>();
	
	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}

	public addTeam(String name) {
		// a local team instance
		Team team = null;

		for (int i = 0; i < teams.size(); ++i) { 
			/* I used the iterator 'for' to go through the elements within the ArrayList. Since there is an 
			   unknown amount within the list, 'i' begins at the first spot and iterates through the size of
			   the list using "teams.size()" and adds 1 after each iteration with '++i' at the end.*/
			if (teams.getTeam().equals(name)) {
				/* The 'if' statement searches the list of teams for a similar team name. If it finds one, it
				 * will change the variable of 'team' to the 'name' that was entered.*/
				return team;
				/* The 'for' loop breaks upon running through all elements and either changes the variable 'team'
				 * to the submitted name, or it continues to have 'null' as its value.*/
			}		
		}
		// if not found, make a new team instance and add to list of teams
		if (team == null) {
			team = new Team(nextTeamId++, name);
			teams.add(team);
		}
		/* After my loop and the if statement below it, there are 1 of 2 outcomes. Either the name of the team that 
		 * was inputed is returned, or it is a new title, and added to the list with a TeamId.*/

		// return the new/existing team instance to the caller
		return team; 
	}

	@Override
	public String toString() {
		
		return "Game [id=" + id + ", name=" + name + "]";
	}

}
