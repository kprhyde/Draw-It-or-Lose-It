package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {
	
	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	private long nextGameId;
	private long nextPlayerId;
	private long nextTeamId;
	private GameService service;
	
	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;
	/*
	 * Singleton Pattern: This is the only point of access to the other classes and only allows that one 
	 * instance of that kind to access it at a time. (Reminds me of my register system at work where multiple
	 * associates can access the register system at one time, but using my private log in, only allows me 
	 * access to one register at any given time. Which I have to sign out of the current one I am using to 
	 * access another.)  
	 */
	private static volatile GameService instance; 
	/* Attribute of singleton pattern. It is volatile because if two of the same instance go through and the
	 * first one makes it to the second null check and is saving into memory, volatile makes the second instance
	 * wait instead of pushing through.*/
	
	private void GameService() { 
	}
	/* A private constructor because it only needs to be accessed through the public constructor below. I 
	 * believe it is an error because it requires a variable to be entered for it to work like the player's
	 * name or id. (Like my sign in to use a register)*/
	
	public static GameService getInstance() {
		if (instance == null) {
			synchronized (GameService.class) {
				if (instance == null) {
					instance = new GameService();
				}
			}
		}
		return instance;
	}
	/* This is the public constructor that checks to see if an instance is already in use. The reason for 
	 * two null checks is if there are two of the same instance trying to access at the exact same time.
	 * They both go through the first check at the same time, but the 'synchronized (GameService.class)' only
	 * allows one instance to pass through at a time. Then the first instance passes the second null check 
	 * creating a new GameService, while the second is pushed to the return. */
	
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {
								// ******* MORE NOTES ARE AT THE BOTTOM OF THE PAGE *******
		// a local game instance
		Game game = null;

		for (int i = 0; i < games.size(); ++i) { 
			/* I used the iterator 'for' to go through the elements within the ArrayList. Since there is an 
			   unknown amount within the list, 'i' begins at the first spot and iterates through the size of
			   the list using "games.size()" and adds 1 after each iteration with '++i' at the end.*/
			if (games.getGame().equals(name)) {
				/* The 'if' statement searches the list of games for a similar game title. If it finds one, it
				 * will change the variable of 'game' to the 'name' that was entered.*/
				return game;
				/* The 'for' loop breaks upon running through all elements and either changes the variable 'game'
				 * to the submitted name, or it continues to have 'null' as its value.*/
			}		
		}
		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}
		/* After my loop and the if statement below it, there are 1 of 2 outcomes. Either the name of the game that 
		 * was inputed is returned, or it is a new title, and added to the list with a GameID.*/

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		for (int i = 0; i < games.size(); ++i) {
			/* Same as before, I used the iterator 'for' to go through the elements within the ArrayList. 
			 * Since there is an unknown amount within the list, 'i' begins at the first spot and iterates 
			 * through the size of the list using "games.size() and adds 1 after each iteration with '++i' 
			 * at the end.*/
			if (games.getId().equals(id)) {
				/* Searches through the 'games' list to find a matching Id number as per the value of 'id'
				 * until it finds a match.*/
				 return game;
				 // Returns the name of the game based on the matching Id value.
				
			}		
		}

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		for (int i = 0; i < games.size(); ++i) {
			/* Same as before, I used the iterator 'for' to go through the elements within the ArrayList. 
			 * Since there is an unknown amount within the list, 'i' begins at the first spot and iterates 
			 * through the size of the list using "games.size() and adds 1 after each iteration with '++i' 
			 * at the end.*/
			if (games.getGame().equals(name)) {
				/* I used 'getGame()' to go through the list of active games to find a game that matches 
				the value of 'name'.*/
				return game;
				// Returns that games name.
			}
		}

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	public long getNextPlayer() {
		
	}
	
	public long getNextTeamID() {
		
	}
}

/* Originally, I wanted to use the 'contains' method for seeing if a game or Id was in the ArrayList. However,
 * I did not know if it would pick up the necessary information because I was testing if the code would work in
 * a separate IDE.
 * 
 * I decided on 'for' iterators because there is a set number of games within the list, and 'while' iterators
 * tend to go on forever if improperly used. 
 *  */