package com.gamingroom;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity {
	
	private static List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}

	public addPlayer(String name) {
		// a local player instance
		Player player = null;

		for (int i = 0; i < players.size(); ++i) { 
			/* I used the iterator 'for' to go through the elements within the ArrayList. Since there is an 
			   unknown amount within the list, 'i' begins at the first spot and iterates through the size of
			   the list using "players.size()" and adds 1 after each iteration with '++i' at the end.*/
			if (players.getPlayer().equals(name)) {
				/* The 'if' statement searches the list of players for a similar player name. If it finds one, it
				 * will change the variable of 'player' to the 'name' that was entered.*/
				return player;
				/* The 'for' loop breaks upon running through all elements and either changes the variable 'player'
				 * to the submitted name, or it continues to have 'null' as its value.*/
			}		
		}
		// if not found, make a new player instance and add to list of players
		if (player == null) {
			player = new Player(nextPlayerId++, name);
			players.add(player);
		}
		/* After my loop and the if statement below it, there are 1 of 2 outcomes. Either the name of the player that 
		 * was inputed is returned, or it is a new title, and added to the list with a PlayerId.*/

		// return the new/existing player instance to the caller
		return player; 
	}
	
	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
