package com.gamingroom;

public class Entity {
	private long id;
	private String name;
	
	private void Entity(); {
		
	}
	
	public void Entity(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}
	
	public getId() {
		return id;
	}
	
	public getName() {
		return name;
	}
	
	@Override
	public toString() {
		return "Game [id=" + id + ", name=" + name + "]";
	}

}
